export default function handler(req, res) {
  const { tz } = req.query;

  const clients = [
    {
      tz: '305562761',
      name: 'ישראל ישראלי',
      salary: 18000,
      incomePerPerson: 6000,
      financingPercentage: 62,
      assets: 1,
      score: 84
    },
    {
      tz: '123456789',
      name: 'דנה כהן',
      salary: 14000,
      incomePerPerson: 4666.66,
      financingPercentage: 75,
      assets: 0,
      score: 58
    }
  ];

  const client = clients.find(c => c.tz === tz);
  if (!client) return res.status(404).json({ error: 'Client not found' });

  res.status(200).json(client);
}