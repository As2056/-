import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';

export default function ClientStatus() {
  const router = useRouter();
  const { tz } = router.query;
  const [client, setClient] = useState(null);

  useEffect(() => {
    if (!tz) return;
    fetch(`/api/client-status?tz=${tz}`)
      .then(res => res.json())
      .then(data => setClient(data));
  }, [tz]);

  if (!tz) return <div>לא סופקה תעודת זהות</div>;
  if (!client) return <div>טוען נתונים...</div>;

  return (
    <div>
      <h1>הסטטוס שלך</h1>
      <p><strong>שם:</strong> {client.name}</p>
      <p><strong>שכר:</strong> {client.salary} ₪</p>
      <p><strong>הכנסה לנפש:</strong> {client.incomePerPerson} ₪</p>
      <p><strong>אחוז מימון:</strong> {client.financingPercentage}%</p>
      <p><strong>נכסים:</strong> {client.assets}</p>
      <p><strong>ציון:</strong> {client.score}</p>
    </div>
  );
}