export default function Home() {
  return <h1>ברוך הבא לדשבורד סטטוס לקוחות</h1>;
}